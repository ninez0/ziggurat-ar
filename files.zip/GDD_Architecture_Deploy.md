# Ziggurat Survivors AR
**Room-scale passthrough "Vampire Survivors" set in Ancient Sumer & historical Iraq — WebXR + Three.js, Meta Quest 2 / 3 / 3S**

Prototype file: `index.html` (single file, Three.js r160 from jsDelivr via an import map).

---

## 1. Design pillars

1. **Your room is the arena.** No tabletop, no diorama. Everything stands on the real floor at `Y = 0`.
2. **Your body is the controller.** Real walking dodges enemies and collects XP. There is no joystick locomotion.
3. **Auto-attack, choose upgrades.** Hands are free; decisions happen at level-up in a floating 3D menu.
4. **Readable in a real room.** Dark floor shadows under every enemy, bright emissive weapons, a floor ring showing HP and pickup radius.

---

## 2. System architecture

```
 ┌────────────────────────── WebXR session (immersive-ar) ──────────────────────────┐
 │ requiredFeatures: local-floor     optional: hand-tracking, plane-detection,      │
 │ alpha canvas, clearAlpha = 0      mesh-detection, anchors                         │
 └───────────────┬──────────────────────────────────────────────────────────────────┘
                 │ XRFrame each tick
        ┌────────▼─────────┐   viewer pose → P.x, P.z (floor), P.headY, P.q
        │  Player tracker  │──────────────────────────────────────────┐
        └────────┬─────────┘   optional: detectedPlanes → floor snap  │
                 │                                                    │
   ┌─────────────▼───────────────┐   ┌───────────────────┐   ┌───────▼────────┐
   │ Game director               │   │ Weapons           │   │ 3D UI          │
   │  • wave curve (tn 0‥15)     │──▶│ Scimitars/Torrent │   │ canvas panels  │
   │  • spawner (ring radius R)  │   │ Flames/Marduk     │   │ ray + pinch +  │
   │  • bosses, minute bursts    │   │ (all read P, S)   │   │ gaze + mouse   │
   └─────────────┬───────────────┘   └─────────┬─────────┘   └───────┬────────┘
                 │                             │                      │
   ┌─────────────▼─────────────────────────────▼──────────────────────▼────────┐
   │ Rendering layer (all children of `world`, floor = local Y 0)               │
   │  4 × InstancedMesh enemies · shadows · gems · glow particles · bolt boxes  │
   │  1 merged mesh per map environment · floor hazard discs                    │
   └────────────────────────────────────────────────────────────────────────────┘
```

**Coordinate frames.** `local-floor` makes `Y = 0` the physical floor. Floor-anchored content lives under `world`, whose `position.y` is nudged (smoothed) if a Quest-detected floor plane disagrees. UI panels, controllers and the HUD sit in the scene root in raw reference-space coordinates.

**Play space.** At *Begin*, the player's current floor position becomes the **arena centre**. Map structures are built on a ring of radius `R_room` around it (Small 1.9 m, Medium 2.7 m, Large 3.5 m). Enemies spawn on a ring of radius `R_spawn` around the **player** (1.7 / 2.3 / 3.0 m), re-rolled if the point lands more than 1.25 × room radius from the arena centre.

**Draw-call budget.** About 25 per frame: 4 enemy instanced meshes, 1 shadow mesh, 1 gem mesh, 1 particle mesh, 1 bolt mesh, 1 environment mesh, up to 4 blades × 3 parts, hazards, UI panel, HUD, rings. Everything animated is instanced; everything static is merged with baked vertex colours.

**Input.** Controller ray + trigger, hand pinch (same `select` events), head-gaze dwell (2.2 s) when nothing is tracked, mouse in desktop preview.

**What "real-world-geometry" means in WebXR.** There is no feature string with that name. The real ones are `plane-detection` and `mesh-detection` (room scan from Quest *Space Setup*). The prototype requests both as *optional* and uses planes to correct the floor height. It does **not** use the mesh for occlusion (see §9).

---

## 3. Core loop

Walk → enemies converge on your floor position → weapons auto-fire → kills drop rune gems **on the floor** → **walk over them** (or let the magnet pull them) → level up → pick 1 of 3 blessings → survive to 15:00 (or die).

**AR adaptation of movement speed.** You can't change how fast a person physically walks, so "move speed" becomes **Tempo**: blade spin rate and Enkidu's enemy-slow aura. Reeds and pools slow enemies by 40–50 % and reduce the player's Tempo by 30 % while you stand in them.

---

## 4. Heroes

| Hero | Identity | Stats |
|---|---|---|
| **Gilgamesh** | Tank-bruiser | 150 HP, ×1.25 area (wider blade orbit / blasts). Starts with Scimitars. |
| **Enkidu** | Skirmisher | ×1.25 Tempo, enemies move 12 % slower, +1.5 HP per kill. Starts with Scimitars. |
| **Inanna** | Spellcaster | 90 HP, ×1.3 spell power (Torrent, Flames, Marduk), ×1.7 gem magnet. Starts with Flames of Ishtar. |

---

## 5. Weapons, passives, evolutions

Design cap: **level 8**. Prototype cap: **level 5** (so a 5-minute test run shows evolutions). ✅ = implemented in `index.html`.

### 5.1 Weapons (8)

| # | Weapon | Behaviour | Scaling |
|---|---|---|---|
| 1 ✅ | **Dual Scimitars of Shamash** | 2 lightning blades orbit your body at chest height; contact applies ticking lightning damage (0.16 s per enemy) and a shock-slow. A grounding arc strikes the floor under each blade; a static discharge zaps the nearest enemy every ~0.45 s. | damage, orbit radius, spin |
| 2 ✅ | **Torrent of Enki** | Tidal ring expands from where you stand to 3–4.5 m, damaging and knocking enemies outward toward the room edges. Bosses take 30 % knockback. | radius, damage, cooldown |
| 3 ✅ | **Flames of Ishtar** | Homing fire seeks the **highest-HP** enemy, explodes in a small area. | projectile count (1→3), damage |
| 4 ✅ | **Staff of Marduk** | Lightning drops from 3.6 m onto the **densest cluster** (scored by neighbours within 0.9 m), stuns briefly. | strikes (1→3), radius, damage |
| 5 | **Lamassu Ward** | 2 stone guardians orbit at floor level, body-block and reflect the first hit from each enemy. | guardians, reflect % |
| 6 | **Cedar Axe of Gilgamesh** | Cone sweep toward your gaze direction every few seconds, cleaves multiple targets. | arc width, damage |
| 7 | **Anzu Wings** | Boomerang feather-blades thrown in a ring, return and hit twice. | feathers, range |
| 8 | **Tablet of Destinies** | Cuneiform curse field around you: damage-over-time plus enemy slow; grows with kills. | radius, DoT |

### 5.2 Passives (8)

| Passive | Effect per level (max 5) |
|---|---|
| ✅ Amulet of Shamash | +15 % damage |
| ✅ Cup of Enki | −10 % cooldowns |
| ✅ Mirror of Ishtar | +12 % area / reach |
| ✅ Lapis Seal | +25 % rune pickup radius |
| ✅ Date-Palm Heart | +20 max HP, +0.3 HP/s |
| ✅ Anzu Feather | +8 % Tempo |
| Seal of Nabu | +10 % XP from runes |
| Cedar Seal of Humbaba | +5 % damage reduction, thorns |

### 5.3 Evolution rules

A weapon at **max level** + its **partner passive at level ≥ 1** adds an *Evolution* card to the next level-up (evolutions are offered before any other card).

| Weapon (max) | + Passive | → Evolution | Result |
|---|---|---|---|
| ✅ Dual Scimitars | Amulet of Shamash | **Storm-Halo of Shamash** | 4 blades, +0.2 m orbit, ×1.5 damage, discharge chains to a 2nd enemy |
| ✅ Torrent of Enki | Cup of Enki | **Deluge of Apsu** | Second wave 0.7 s behind the first, knockback 5.5 → 8 |
| ✅ Flames of Ishtar | Mirror of Ishtar | **Ishtar's Descent** | Double volley; each blast leaves a 3 s burning pool |
| ✅ Staff of Marduk | Lapis Seal | **Wrath of Marduk** | Each strike chains to a nearby enemy for 50 % damage |
| Lamassu Ward | Date-Palm Heart | **Ward of Nineveh** | 4 guardians, heal on reflect |
| Cedar Axe | Cedar Seal of Humbaba | **Forest-Splitter** | Full 360° spin, bleed |
| Anzu Wings | Anzu Feather | **Storm-Bird Anzu** | Orbiting storm-bird that auto-hunts |
| Tablet of Destinies | Seal of Nabu | **Tablet of Fates** | Curse field marks enemies; marked kills double XP |

---

## 6. Enemies

| Type | Model | Role | Base HP | Speed | Notes |
|---|---|---|---|---|---|
| Mushussu Beast | serpent-dragon hound | swarmer | 12 | 1.5 | low, fast |
| Shadow Djinn | floating smoke wraith | harasser | 18 | 1.1 | hovers 0.18 m above floor |
| Babylonian Spearman | helmeted infantry | line holder | 35 | 0.95 | +0.45 m spear reach |
| Lamassu Guardian | winged stone bull | brute | 140 | 0.7 | also the **boss** body, scaled and red-tinted |
| **Bosses** | Humbaba (5:00) · Bull of Heaven (10:00) · Ereshkigal's Herald (14:00) | | 8× / 14× / 22× | | drop a rune shower |

Enemies *grow up out of the floor* (scale 0 → 1 over 0.6 s) instead of sinking below it. See §9 for why.

---

## 7. Maps (all structures anchored to the floor)

| Map | Perimeter structures | Floor hazard | Ambient | Spawn × / HP × |
|---|---|---|---|---|
| **Ziggurat of Ur** | 2 stepped mud-brick ziggurats with ramps, altars with flames, broken walls | — | Dust storm | 1.00 / 1.00 |
| **Ishtar Gate** | 3 lapis arches with gold bands and reliefs, 3 lion guardians | — | — | 1.05 / 1.05 |
| **Hanging Gardens** | 4 terraces with pergolas, hanging vines, flowers | **Poison-ivy patches ×6** — 5 HP/s to you, 4 HP/s to enemies | Falling petals | 1.00 / 1.00 |
| **Citadel of Erbil** | Battlement wall segments, 2 towers | **Siege spike traps ×4** — 6 HP/s to you, 10 HP/s to enemies | — | 1.10 / 1.15 |
| **Ahwar Marshes** | Tall reed walls, mashoof boat | **Reed beds ×6, pools ×3** — enemies −40–50 % speed; your Tempo −30 % | Low mist | 1.10 / 0.95 |

Hazards are drawn as translucent floor discs with a bright rim so they read against any carpet.

---

## 8. Difficulty curve, minute 0 → 15

The run length is normalised: `tn = elapsed / runLength × 15`. So the 5-minute quick test plays the same curve three times faster.

**Global formulas** (multiply spawn rate by the map's spawn ×, HP by the map's HP ×):

| tn (min) | Spawn interval | Alive cap | Enemy HP × | Event |
|---|---|---|---|---|
| 0 | 1.30 s | 12 | 1.00 | Beasts only |
| 1 | 1.23 s | 15 | 1.17 | Spearmen begin on some maps |
| 2 | 1.16 s | 18 | 1.34 | **Ring burst** every minute from here (6 + minute, max 14 beasts, evenly around you) |
| 3 | 1.09 s | 22 | 1.51 | |
| 5 | 0.95 s | 28 | 1.85 | **Boss 1** |
| 7 | 0.81 s | 34 | 2.19 | |
| 9 | 0.67 s | 41 | 2.53 | **Double spawns per tick** from here |
| 10 | 0.60 s | 44 | 2.70 | **Boss 2** |
| 12 | 0.46 s | 50 | 3.04 | |
| 14 | 0.32 s | 56 (hard cap) | 3.38 | **Boss 3** |
| 15 | 0.30 s | 56 | 3.55 | Victory if alive |

**Enemy mix per map** (relative weight; the number after "@" is the minute it unlocks):

| Map | Beast | Djinn | Spearman | Lamassu |
|---|---|---|---|---|
| Ziggurat of Ur | 6 | 2 @2 | 3 @1 | 1 @4 |
| Ishtar Gate | 3 | 1 @3 | 5 @0.5 | 2 @3 |
| Hanging Gardens | 3 | 5 @1 | 2 | 1 @5 |
| Citadel of Erbil | 2 | 1 @2 | 6 | 3 @3 |
| Ahwar Marshes | 5 | 4 @1.5 | 1 @2 | 1 @6 |

XP per level: `round(5 + 4L + 0.7L²)` (level 2 needs 10, level 5 needs 42, level 10 needs 115).

---

## 9. AR-specific design rules and known limits

- **No negative Y.** Passthrough has no depth occlusion in this prototype, so geometry below the floor would float visibly *through* it. Enemies scale up from the floor; nothing is ever placed below `Y = 0`.
- **Walls aren't solid.** The game doesn't know where your walls are. The arena radius setting and the spawn re-roll keep most action inside; props on the perimeter can overlap walls. Pick the room size that fits.
- **Floor accuracy.** `local-floor` is good but can drift a few cm. If the Quest has a Space Setup scan, `plane-detection` snaps the floor automatically.
- **Next steps.** Quest 3 depth sensing for real occlusion (enemies pass behind sofas); anchors so the arena stays fixed if tracking recenters; mesh-detection to spawn only on free floor; 24 more upgrade cards; save data for meta-progression.
- **Physical safety.** Clear the floor, remove tripping hazards, keep pets and people out. Walk, don't run. If the Quest guardian/boundary appears, stop and recentre.

---

## 10. Deploy & play guide (Meta Quest 3 / 3S / 2)

WebXR **only works over HTTPS**, so you must host the file; opening it from local storage won't start AR.

### Step 1 — Free hosting

**Option A: GitHub Pages**
1. Create a free GitHub account → **New repository** → name it `ziggurat-ar`, set **Public**.
2. **Add file → Upload files**. Drag in `index.html`. Commit.
3. **Settings → Pages**. Under *Build and deployment*, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, **Save**.
4. After about a minute your URL appears: `https://YOUR-USERNAME.github.io/ziggurat-ar/`

**Option B: Netlify (fastest, no git)**
1. Put `index.html` in a folder called `ziggurat-ar`.
2. Open `app.netlify.com/drop` and drag the **folder** onto the page (free account).
3. Netlify gives you a `https://something.netlify.app` URL immediately. Rename it in *Site configuration* if you like.

### Step 2 — Open it on the headset

1. Put on the Quest and open the **Meta Quest Browser** (the Browser app in your library).
2. Type your URL in the address bar (or send it from your phone with the Meta Horizon app, or paste it into a note you can open on the headset). **Bookmark it.**
3. The page shows a title screen and **"Enter AR (passthrough)"**. If the button is greyed out, see Troubleshooting.
4. Press **Enter AR**. The browser asks for permission to use your surroundings / spatial data. **Allow.** Optional features (hand tracking, planes, mesh) are requested; the game still works if you decline them.
5. Your room appears (grayscale on Quest 2, colour on Quest 3 / 3S) with a floating menu about 1 m ahead.
6. **Stand in the middle of the room**, then pick:
   - **Hero**, **Battlefield**, **Room size** (match your clear floor space), **Run length** (Quick Test 5 min / Full 15 min).
   - Press **BEGIN** with the controller trigger or a hand **pinch** on the menu button. If nothing is tracked, look at a button for about 2 seconds.
7. **Play:** Sumerian beasts rise from your floor ring-wise. Your blades orbit automatically. Walk toward glowing gems to collect them. Every level pauses the action and floats three cards in front of you — point and pick.
8. Quit by pressing the Meta button and choosing *Exit*, or finish the run and use *Return to the menu*.

### Troubleshooting

| Symptom | Fix |
|---|---|
| "Enter AR" is greyed out | Use the **Meta Quest Browser**, update it and the Quest OS, and make sure the URL starts with `https://`. |
| Everything is black, no room visible | The session wasn't `immersive-ar`. Reload, press **Enter AR** (not Desktop preview). Check Quest settings allow passthrough in the browser. |
| Floor feels too high or low | Redo **Space Setup** / floor calibration in the Quest settings, then reload. Detected planes will refine it. |
| Enemies appear behind walls | Choose a smaller **Room size**, or play from the middle of the room. |
| Menu is hard to hit | Move your hand closer to centre; the menu faces you. Gaze-dwell works if controllers are asleep. |
| Frame rate dips late in a run | Shrink the room size (lower enemy cap pressure) or restart; the game caps at 56 enemies. |
| Page works on desktop but not on Quest | Hosting must be HTTPS; some corporate/school networks block the jsDelivr CDN. Self-host Three.js by downloading `three.module.js` and `BufferGeometryUtils.js` into the repo and changing the import map. |

**Desktop preview (testing without a headset):** open the page in Chrome, press *Desktop preview*, move with **W A S D**, turn with **Q / E**, click menu buttons with the mouse.
